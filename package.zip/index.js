// Get spreadsheet npm package 
const { GoogleSpreadsheet, GoogleSpreadsheetRow } = require('google-spreadsheet');
// Ensure you've updated this file with your client secret
const clientSecret = require('./client_secret.json');

// Rest api module
const axios = require('axios')

//file system module
const fs = require('fs');

//googleapis
const { google } = require('googleapis');

// //path module
// const path = require('path');
const { Readable } = require('stream')

// Add your Google sheet ID here
const googleSheetID = '1a3U5qIu_tliESfWp1hskfxjsUDSi-6Z3IHAwuUShPMA'; // Nilesh Roy

// Instantiates the spreadsheet
const doc = new GoogleSpreadsheet(googleSheetID);

// Asynchronously get the data
async function getData() {
    try {
        // Authenticate using the JSON file we set up earlier
        await doc.useServiceAccountAuth(clientSecret);
        await doc.loadInfo();

        console.log('Info:: Google SheetDoc Title => ' + doc.title);
        const sheet = doc.sheetsByTitle['Sheet2'];
        console.log('Info:: Google Sheet Title => ' + sheet.title);

        let rows = await sheet.getRows();

        for (let index = 0; index < rows.length; index++) {
            const x = rows[index];
            if (x.type.toLowerCase() === 'image' && x.data && !x.TestWebLink) {
                console.log(`Info:: Row type  => ${x.type}  |  Row data  => ${x.data}`);
                const bufferArray = await getWatiMediaData(x.data);
                if (!bufferArray) {
                    console.log(`Info :: Image not found from wati api. for ${x.id}`);
                    continue;
                }
                console.log(`Info :: Image found from wati api.`);

                const imageName = `wati_${x.id}.jpeg`;
                const uploadRes = await uploadMediaToGDrive(bufferArray, imageName);
                if (uploadRes && uploadRes.id) {
                    console.log(`Info :: Upload Image to GDrive. FileId :  ${uploadRes.id}`);
                    rows[index].TestWebLink = uploadRes.webViewLink;
                    await rows[index].save()
                }
            }

        }

    } catch (err) {
        console.log('error in getData()');
        console.log(err);
        return false;
    }
}

async function getWatiMediaData(url) {
    try {
        var config = {
            responseType: 'arraybuffer',
            headers: {
                'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI5MTAyMjZmOC02YTEyLTRmODUtOGY1NC00ODZjYjI0OGI2NzAiLCJ1bmlxdWVfbmFtZSI6ImkuYW5pa2V0LnNhbWFudGFAZ21haWwuY29tIiwibmFtZWlkIjoiaS5hbmlrZXQuc2FtYW50YUBnbWFpbC5jb20iLCJlbWFpbCI6ImkuYW5pa2V0LnNhbWFudGFAZ21haWwuY29tIiwiYXV0aF90aW1lIjoiMDUvMTgvMjAyMiAwNDo0MTowOSIsImRiX25hbWUiOiI5MjYxIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjoiREVWRUxPUEVSIiwiZXhwIjoyNTM0MDIzMDA4MDAsImlzcyI6IkNsYXJlX0FJIiwiYXVkIjoiQ2xhcmVfQUkifQ.9JpL11ehn6CiLcpjLHwVe-3J7mvnXdu-X9Ujab0F5C0',
                // 'Cookie': 'affinity=1652862490.535.230345.51127|e23358b735f7530e366ebb3a6713a38c'
            }
        };
        const response = await axios.get(url, config);

        if (response && response.data) {
            return response.data;
        } else {
            console.log('error in getWatiMediaData()');
            console.log(`No image found from wati api = > ${url}`);
            throw error;
        }
    } catch (error) {
        console.log('error in getWatiMediaData()');
        console.log(error);
        return false;
    }
}

async function uploadMediaToGDrive(body, fileName) {
    // configure a JWT auth client
    let jwtClient = new google.auth.JWT(
        clientSecret.client_email,
        null,
        clientSecret.private_key,
        ['https://www.googleapis.com/auth/drive']);

    //authenticate request
    jwtClient.authorize(function (err, tokens) {
        if (err) {
            console.log(err);
            return;
        } else {
            console.log("Successfully connected!");
        }
    });

    //initialize google drive
    const drive = google.drive({
        version: 'v3',
        auth: jwtClient,
    });
    fs.ReadStream

    try {
        const response = await drive.files.create({
            requestBody: {
                name: fileName, //file name
                mimeType: 'image/jpeg',
                parents: ['1RwOEbZKff8qW8PNF0yFdqFwXblnEM-Vj']
            },
            fields: 'webViewLink, webContentLink,id,name',
            media: {
                mimeType: 'image/jpeg',
                body: Readable.from(body),
            },
        });
        return response.data;
    } catch (error) {
        //report the error message
        console.log('Info :: uploadMediaToGDrive= > ' + error.message);
    }
}

// //create a public url
// async function generatePublicUrl(id) {
//     try {
//         // configure a JWT auth client
//         let jwtClient = new google.auth.JWT(
//             clientSecret.client_email,
//             null,
//             clientSecret.private_key,
//             ['https://www.googleapis.com/auth/drive']);

//         //authenticate request
//         jwtClient.authorize(function (err, tokens) {
//             if (err) {
//                 console.log(err);
//                 return;
//             } else {
//                 console.log("Successfully connected!");
//             }
//         });

//         //initialize google drive
//         const drive = google.drive({
//             version: 'v3',
//             auth: jwtClient,
//         });

//         const fileId = id //'16YtH8Rj6Gf3_XAjHuB3HslZ1bo2ia1Ly';
//         //change file permisions to public.
//         await drive.permissions.create({
//             fileId: fileId,
//             requestBody: {
//                 role: 'reader',
//                 type: 'anyone',
//             },
//         });

//         //obtain the webview and webcontent links
//         const result = await drive.files.get({
//             fileId: fileId,
//             fields: 'webViewLink, webContentLink',
//         });
//         console.log(result.data);
//     } catch (error) {
//         console.log(error.message);
//     }
// }

// Call the above method


exports.executeFunction = async (req, res) => {
    let stopWatchStart = performance.now();
    await getData();
    let stopWatchEnd = performance.now();
    let message = `Completed the task :: Total Time Taken ${stopWatchEnd - stopWatchStart} ms`;
    res.status(200).send(message);
};



//https://chrisboakes.com/building-a-rest-api-with-google-sheets-and-aws-lambda/